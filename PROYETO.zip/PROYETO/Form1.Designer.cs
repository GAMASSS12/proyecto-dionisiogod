﻿namespace PROYETO
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            materialTabControl1 = new MaterialSkin.Controls.MaterialTabControl();
            tabPage1 = new TabPage();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            tabPage2 = new TabPage();
            materialTextBox7 = new MaterialSkin.Controls.MaterialTextBox();
            materialTextBox6 = new MaterialSkin.Controls.MaterialTextBox();
            materialTextBox5 = new MaterialSkin.Controls.MaterialTextBox();
            materialTextBox4 = new MaterialSkin.Controls.MaterialTextBox();
            materialTextBox3 = new MaterialSkin.Controls.MaterialTextBox();
            materialTextBox2 = new MaterialSkin.Controls.MaterialTextBox();
            materialTextBox1 = new MaterialSkin.Controls.MaterialTextBox();
            tabPage3 = new TabPage();
            materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            materialComboBox3 = new MaterialSkin.Controls.MaterialComboBox();
            materialComboBox2 = new MaterialSkin.Controls.MaterialComboBox();
            materialComboBox1 = new MaterialSkin.Controls.MaterialComboBox();
            materialTextBox10 = new MaterialSkin.Controls.MaterialTextBox();
            materialTextBox9 = new MaterialSkin.Controls.MaterialTextBox();
            materialTextBox8 = new MaterialSkin.Controls.MaterialTextBox();
            tabPage4 = new TabPage();
            materialButton1 = new MaterialSkin.Controls.MaterialButton();
            materialComboBox4 = new MaterialSkin.Controls.MaterialComboBox();
            materialTextBox13 = new MaterialSkin.Controls.MaterialTextBox();
            materialTextBox12 = new MaterialSkin.Controls.MaterialTextBox();
            materialTextBox11 = new MaterialSkin.Controls.MaterialTextBox();
            imageList1 = new ImageList(components);
            materialTabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            tabPage4.SuspendLayout();
            SuspendLayout();
            // 
            // materialTabControl1
            // 
            materialTabControl1.Controls.Add(tabPage1);
            materialTabControl1.Controls.Add(tabPage2);
            materialTabControl1.Controls.Add(tabPage3);
            materialTabControl1.Controls.Add(tabPage4);
            materialTabControl1.Depth = 0;
            materialTabControl1.Dock = DockStyle.Fill;
            materialTabControl1.ImageList = imageList1;
            materialTabControl1.Location = new Point(3, 64);
            materialTabControl1.MouseState = MaterialSkin.MouseState.HOVER;
            materialTabControl1.Multiline = true;
            materialTabControl1.Name = "materialTabControl1";
            materialTabControl1.SelectedIndex = 0;
            materialTabControl1.Size = new Size(810, 420);
            materialTabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(pictureBox2);
            tabPage1.Controls.Add(pictureBox1);
            tabPage1.Controls.Add(label1);
            tabPage1.ImageKey = "icons8-home-32.png";
            tabPage1.Location = new Point(4, 39);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(802, 377);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "INICIO";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources._061721_090606_l17;
            pictureBox2.Location = new Point(294, 217);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(325, 142);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.OIP;
            pictureBox1.Location = new Point(26, 228);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(214, 127);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 3);
            label1.Name = "label1";
            label1.Size = new Size(713, 165);
            label1.TabIndex = 0;
            label1.Text = resources.GetString("label1.Text");
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(materialTextBox7);
            tabPage2.Controls.Add(materialTextBox6);
            tabPage2.Controls.Add(materialTextBox5);
            tabPage2.Controls.Add(materialTextBox4);
            tabPage2.Controls.Add(materialTextBox3);
            tabPage2.Controls.Add(materialTextBox2);
            tabPage2.Controls.Add(materialTextBox1);
            tabPage2.ImageKey = "icons8-document-32.png";
            tabPage2.Location = new Point(4, 39);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(802, 377);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "INFORMACIÓN";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // materialTextBox7
            // 
            materialTextBox7.AnimateReadOnly = false;
            materialTextBox7.BorderStyle = BorderStyle.None;
            materialTextBox7.Depth = 0;
            materialTextBox7.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox7.Hint = "CP";
            materialTextBox7.LeadingIcon = null;
            materialTextBox7.Location = new Point(205, 157);
            materialTextBox7.MaxLength = 50;
            materialTextBox7.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox7.Multiline = false;
            materialTextBox7.Name = "materialTextBox7";
            materialTextBox7.Size = new Size(160, 50);
            materialTextBox7.TabIndex = 6;
            materialTextBox7.Text = "";
            materialTextBox7.TrailingIcon = null;
            materialTextBox7.TextChanged += materialTextBox7_TextChanged;
            // 
            // materialTextBox6
            // 
            materialTextBox6.AnimateReadOnly = false;
            materialTextBox6.BorderStyle = BorderStyle.None;
            materialTextBox6.Depth = 0;
            materialTextBox6.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox6.Hint = "ABICACIÓN";
            materialTextBox6.LeadingIcon = null;
            materialTextBox6.Location = new Point(205, 86);
            materialTextBox6.MaxLength = 50;
            materialTextBox6.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox6.Multiline = false;
            materialTextBox6.Name = "materialTextBox6";
            materialTextBox6.Size = new Size(160, 50);
            materialTextBox6.TabIndex = 5;
            materialTextBox6.Text = "";
            materialTextBox6.TrailingIcon = null;
            // 
            // materialTextBox5
            // 
            materialTextBox5.AnimateReadOnly = false;
            materialTextBox5.BorderStyle = BorderStyle.None;
            materialTextBox5.Depth = 0;
            materialTextBox5.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox5.Hint = "TELEFONO";
            materialTextBox5.LeadingIcon = null;
            materialTextBox5.Location = new Point(205, 21);
            materialTextBox5.MaxLength = 50;
            materialTextBox5.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox5.Multiline = false;
            materialTextBox5.Name = "materialTextBox5";
            materialTextBox5.Size = new Size(160, 50);
            materialTextBox5.TabIndex = 4;
            materialTextBox5.Text = "";
            materialTextBox5.TrailingIcon = null;
            materialTextBox5.TextChanged += materialTextBox5_TextChanged;
            // 
            // materialTextBox4
            // 
            materialTextBox4.AnimateReadOnly = false;
            materialTextBox4.BorderStyle = BorderStyle.None;
            materialTextBox4.Depth = 0;
            materialTextBox4.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox4.Hint = "EMPRESA";
            materialTextBox4.LeadingIcon = null;
            materialTextBox4.Location = new Point(6, 224);
            materialTextBox4.MaxLength = 50;
            materialTextBox4.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox4.Multiline = false;
            materialTextBox4.Name = "materialTextBox4";
            materialTextBox4.Size = new Size(160, 50);
            materialTextBox4.TabIndex = 3;
            materialTextBox4.Text = "";
            materialTextBox4.TrailingIcon = null;
            // 
            // materialTextBox3
            // 
            materialTextBox3.AnimateReadOnly = false;
            materialTextBox3.BorderStyle = BorderStyle.None;
            materialTextBox3.Depth = 0;
            materialTextBox3.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox3.Hint = "EMAIL";
            materialTextBox3.LeadingIcon = null;
            materialTextBox3.Location = new Point(6, 157);
            materialTextBox3.MaxLength = 50;
            materialTextBox3.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox3.Multiline = false;
            materialTextBox3.Name = "materialTextBox3";
            materialTextBox3.Size = new Size(160, 50);
            materialTextBox3.TabIndex = 2;
            materialTextBox3.Text = "";
            materialTextBox3.TrailingIcon = null;
            // 
            // materialTextBox2
            // 
            materialTextBox2.AnimateReadOnly = false;
            materialTextBox2.BorderStyle = BorderStyle.None;
            materialTextBox2.Depth = 0;
            materialTextBox2.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox2.Hint = "APELLIDO";
            materialTextBox2.LeadingIcon = null;
            materialTextBox2.Location = new Point(6, 86);
            materialTextBox2.MaxLength = 50;
            materialTextBox2.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox2.Multiline = false;
            materialTextBox2.Name = "materialTextBox2";
            materialTextBox2.Size = new Size(160, 50);
            materialTextBox2.TabIndex = 1;
            materialTextBox2.Text = "";
            materialTextBox2.TrailingIcon = null;
            materialTextBox2.TextChanged += materialTextBox2_TextChanged;
            // 
            // materialTextBox1
            // 
            materialTextBox1.AnimateReadOnly = false;
            materialTextBox1.BorderStyle = BorderStyle.None;
            materialTextBox1.Depth = 0;
            materialTextBox1.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox1.Hint = "NOMBRE";
            materialTextBox1.LeadingIcon = null;
            materialTextBox1.Location = new Point(6, 21);
            materialTextBox1.MaxLength = 50;
            materialTextBox1.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox1.Multiline = false;
            materialTextBox1.Name = "materialTextBox1";
            materialTextBox1.Size = new Size(160, 50);
            materialTextBox1.TabIndex = 0;
            materialTextBox1.Text = "";
            materialTextBox1.TrailingIcon = null;
            materialTextBox1.TextChanged += materialTextBox1_TextChanged;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(materialLabel1);
            tabPage3.Controls.Add(materialComboBox3);
            tabPage3.Controls.Add(materialComboBox2);
            tabPage3.Controls.Add(materialComboBox1);
            tabPage3.Controls.Add(materialTextBox10);
            tabPage3.Controls.Add(materialTextBox9);
            tabPage3.Controls.Add(materialTextBox8);
            tabPage3.ImageKey = "icons8-checklist-32.png";
            tabPage3.Location = new Point(4, 39);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(802, 377);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "REQUERIMENTOS";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // materialLabel1
            // 
            materialLabel1.AutoSize = true;
            materialLabel1.Depth = 0;
            materialLabel1.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialLabel1.Location = new Point(40, 16);
            materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            materialLabel1.Name = "materialLabel1";
            materialLabel1.Size = new Size(186, 19);
            materialLabel1.TabIndex = 6;
            materialLabel1.Text = "INFORMACIÓN DEÑ TUBO";
            // 
            // materialComboBox3
            // 
            materialComboBox3.AutoResize = false;
            materialComboBox3.BackColor = Color.FromArgb(255, 255, 255);
            materialComboBox3.Depth = 0;
            materialComboBox3.DrawMode = DrawMode.OwnerDrawVariable;
            materialComboBox3.DropDownHeight = 174;
            materialComboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
            materialComboBox3.DropDownWidth = 121;
            materialComboBox3.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold, GraphicsUnit.Pixel);
            materialComboBox3.ForeColor = Color.FromArgb(222, 0, 0, 0);
            materialComboBox3.FormattingEnabled = true;
            materialComboBox3.Hint = "TIPO DE MATERIAL";
            materialComboBox3.IntegralHeight = false;
            materialComboBox3.ItemHeight = 43;
            materialComboBox3.Items.AddRange(new object[] { "N80Q", "TRC95BDC", "J55", "TRC95", "P110" });
            materialComboBox3.Location = new Point(404, 75);
            materialComboBox3.MaxDropDownItems = 4;
            materialComboBox3.MouseState = MaterialSkin.MouseState.OUT;
            materialComboBox3.Name = "materialComboBox3";
            materialComboBox3.Size = new Size(150, 49);
            materialComboBox3.StartIndex = 0;
            materialComboBox3.TabIndex = 5;
            // 
            // materialComboBox2
            // 
            materialComboBox2.AutoResize = false;
            materialComboBox2.BackColor = Color.FromArgb(255, 255, 255);
            materialComboBox2.Depth = 0;
            materialComboBox2.DrawMode = DrawMode.OwnerDrawVariable;
            materialComboBox2.DropDownHeight = 174;
            materialComboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            materialComboBox2.DropDownWidth = 121;
            materialComboBox2.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold, GraphicsUnit.Pixel);
            materialComboBox2.ForeColor = Color.FromArgb(222, 0, 0, 0);
            materialComboBox2.FormattingEnabled = true;
            materialComboBox2.Hint = "GRADOS DE MATERIAL";
            materialComboBox2.IntegralHeight = false;
            materialComboBox2.ItemHeight = 43;
            materialComboBox2.Items.AddRange(new object[] { "350", "919", "72", "339", "450" });
            materialComboBox2.Location = new Point(221, 75);
            materialComboBox2.MaxDropDownItems = 4;
            materialComboBox2.MouseState = MaterialSkin.MouseState.OUT;
            materialComboBox2.Name = "materialComboBox2";
            materialComboBox2.Size = new Size(150, 49);
            materialComboBox2.StartIndex = 0;
            materialComboBox2.TabIndex = 4;
            // 
            // materialComboBox1
            // 
            materialComboBox1.AutoResize = false;
            materialComboBox1.BackColor = Color.FromArgb(255, 255, 255);
            materialComboBox1.Depth = 0;
            materialComboBox1.DrawMode = DrawMode.OwnerDrawVariable;
            materialComboBox1.DropDownHeight = 174;
            materialComboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            materialComboBox1.DropDownWidth = 121;
            materialComboBox1.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold, GraphicsUnit.Pixel);
            materialComboBox1.ForeColor = Color.FromArgb(222, 0, 0, 0);
            materialComboBox1.FormattingEnabled = true;
            materialComboBox1.Hint = "MATERIAL";
            materialComboBox1.IntegralHeight = false;
            materialComboBox1.ItemHeight = 43;
            materialComboBox1.Items.AddRange(new object[] { "ACERO", "COBRE", "ALUMINIO", "LATON", "BRONCE" });
            materialComboBox1.Location = new Point(24, 75);
            materialComboBox1.MaxDropDownItems = 4;
            materialComboBox1.MouseState = MaterialSkin.MouseState.OUT;
            materialComboBox1.Name = "materialComboBox1";
            materialComboBox1.Size = new Size(150, 49);
            materialComboBox1.StartIndex = 0;
            materialComboBox1.TabIndex = 3;
            materialComboBox1.SelectedIndexChanged += materialComboBox1_SelectedIndexChanged;
            // 
            // materialTextBox10
            // 
            materialTextBox10.AnimateReadOnly = false;
            materialTextBox10.BorderStyle = BorderStyle.None;
            materialTextBox10.Depth = 0;
            materialTextBox10.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox10.Hint = "METROS DE TUBO";
            materialTextBox10.LeadingIcon = null;
            materialTextBox10.Location = new Point(209, 165);
            materialTextBox10.MaxLength = 50;
            materialTextBox10.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox10.Multiline = false;
            materialTextBox10.Name = "materialTextBox10";
            materialTextBox10.Size = new Size(150, 50);
            materialTextBox10.TabIndex = 2;
            materialTextBox10.Text = "";
            materialTextBox10.TrailingIcon = null;
            materialTextBox10.TextChanged += materialTextBox10_TextChanged;
            // 
            // materialTextBox9
            // 
            materialTextBox9.AnimateReadOnly = false;
            materialTextBox9.BorderStyle = BorderStyle.None;
            materialTextBox9.Depth = 0;
            materialTextBox9.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox9.Hint = "DIESPESOR (ln)";
            materialTextBox9.LeadingIcon = null;
            materialTextBox9.Location = new Point(24, 235);
            materialTextBox9.MaxLength = 50;
            materialTextBox9.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox9.Multiline = false;
            materialTextBox9.Name = "materialTextBox9";
            materialTextBox9.Size = new Size(150, 50);
            materialTextBox9.TabIndex = 1;
            materialTextBox9.Text = "";
            materialTextBox9.TrailingIcon = null;
            materialTextBox9.TextChanged += materialTextBox9_TextChanged;
            // 
            // materialTextBox8
            // 
            materialTextBox8.AnimateReadOnly = false;
            materialTextBox8.BorderStyle = BorderStyle.None;
            materialTextBox8.Depth = 0;
            materialTextBox8.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox8.Hint = "DIAMETRO (ln)";
            materialTextBox8.LeadingIcon = null;
            materialTextBox8.Location = new Point(24, 165);
            materialTextBox8.MaxLength = 50;
            materialTextBox8.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox8.Multiline = false;
            materialTextBox8.Name = "materialTextBox8";
            materialTextBox8.Size = new Size(150, 50);
            materialTextBox8.TabIndex = 0;
            materialTextBox8.Text = "";
            materialTextBox8.TrailingIcon = null;
            materialTextBox8.TextChanged += materialTextBox8_TextChanged;
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(materialButton1);
            tabPage4.Controls.Add(materialComboBox4);
            tabPage4.Controls.Add(materialTextBox13);
            tabPage4.Controls.Add(materialTextBox12);
            tabPage4.Controls.Add(materialTextBox11);
            tabPage4.ImageKey = "icons8-bank-card-dollar-32.png";
            tabPage4.Location = new Point(4, 39);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(802, 377);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "PAGOS";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // materialButton1
            // 
            materialButton1.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            materialButton1.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            materialButton1.Depth = 0;
            materialButton1.HighEmphasis = true;
            materialButton1.Icon = null;
            materialButton1.Location = new Point(360, 251);
            materialButton1.Margin = new Padding(4, 6, 4, 6);
            materialButton1.MouseState = MaterialSkin.MouseState.HOVER;
            materialButton1.Name = "materialButton1";
            materialButton1.NoAccentTextColor = Color.Empty;
            materialButton1.Size = new Size(105, 36);
            materialButton1.TabIndex = 4;
            materialButton1.Text = "CONFIRMAR";
            materialButton1.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            materialButton1.UseAccentColor = false;
            materialButton1.UseVisualStyleBackColor = true;
            materialButton1.Click += materialButton1_Click;
            // 
            // materialComboBox4
            // 
            materialComboBox4.AutoResize = false;
            materialComboBox4.BackColor = Color.FromArgb(255, 255, 255);
            materialComboBox4.Depth = 0;
            materialComboBox4.DrawMode = DrawMode.OwnerDrawVariable;
            materialComboBox4.DropDownHeight = 174;
            materialComboBox4.DropDownStyle = ComboBoxStyle.DropDownList;
            materialComboBox4.DropDownWidth = 121;
            materialComboBox4.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold, GraphicsUnit.Pixel);
            materialComboBox4.ForeColor = Color.FromArgb(222, 0, 0, 0);
            materialComboBox4.FormattingEnabled = true;
            materialComboBox4.IntegralHeight = false;
            materialComboBox4.ItemHeight = 43;
            materialComboBox4.Items.AddRange(new object[] { "DEBITO ", "CREDITO" });
            materialComboBox4.Location = new Point(22, 30);
            materialComboBox4.MaxDropDownItems = 4;
            materialComboBox4.MouseState = MaterialSkin.MouseState.OUT;
            materialComboBox4.Name = "materialComboBox4";
            materialComboBox4.Size = new Size(179, 49);
            materialComboBox4.StartIndex = 0;
            materialComboBox4.TabIndex = 3;
            // 
            // materialTextBox13
            // 
            materialTextBox13.AnimateReadOnly = false;
            materialTextBox13.BorderStyle = BorderStyle.None;
            materialTextBox13.Depth = 0;
            materialTextBox13.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox13.Hint = "CVV";
            materialTextBox13.LeadingIcon = null;
            materialTextBox13.Location = new Point(207, 173);
            materialTextBox13.MaxLength = 50;
            materialTextBox13.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox13.Multiline = false;
            materialTextBox13.Name = "materialTextBox13";
            materialTextBox13.Size = new Size(123, 50);
            materialTextBox13.TabIndex = 2;
            materialTextBox13.Text = "";
            materialTextBox13.TrailingIcon = null;
            materialTextBox13.TextChanged += materialTextBox13_TextChanged;
            // 
            // materialTextBox12
            // 
            materialTextBox12.AnimateReadOnly = false;
            materialTextBox12.BorderStyle = BorderStyle.None;
            materialTextBox12.Depth = 0;
            materialTextBox12.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox12.Hint = "VENCIMIENTO";
            materialTextBox12.LeadingIcon = null;
            materialTextBox12.Location = new Point(22, 177);
            materialTextBox12.MaxLength = 50;
            materialTextBox12.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox12.Multiline = false;
            materialTextBox12.Name = "materialTextBox12";
            materialTextBox12.Size = new Size(139, 50);
            materialTextBox12.TabIndex = 1;
            materialTextBox12.Text = "";
            materialTextBox12.TrailingIcon = null;
            materialTextBox12.TextChanged += materialTextBox12_TextChanged;
            // 
            // materialTextBox11
            // 
            materialTextBox11.AnimateReadOnly = false;
            materialTextBox11.BorderStyle = BorderStyle.None;
            materialTextBox11.Depth = 0;
            materialTextBox11.Font = new Font("Roboto", 16F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialTextBox11.Hint = "NUMERO DE LA TARJETA";
            materialTextBox11.LeadingIcon = null;
            materialTextBox11.Location = new Point(19, 100);
            materialTextBox11.MaxLength = 50;
            materialTextBox11.MouseState = MaterialSkin.MouseState.OUT;
            materialTextBox11.Multiline = false;
            materialTextBox11.Name = "materialTextBox11";
            materialTextBox11.Size = new Size(228, 50);
            materialTextBox11.TabIndex = 0;
            materialTextBox11.Text = "";
            materialTextBox11.TrailingIcon = null;
            materialTextBox11.TextChanged += materialTextBox11_TextChanged;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth32Bit;
            imageList1.ImageStream = (ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = Color.Transparent;
            imageList1.Images.SetKeyName(0, "icons8-checklist-32.png");
            imageList1.Images.SetKeyName(1, "icons8-home-32.png");
            imageList1.Images.SetKeyName(2, "icons8-bank-card-dollar-32.png");
            imageList1.Images.SetKeyName(3, "icons8-document-32.png");
            imageList1.Images.SetKeyName(4, "icons8-add-bookmark-32.png");
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(816, 487);
            Controls.Add(materialTabControl1);
            DrawerShowIconsWhenHidden = true;
            DrawerTabControl = materialTabControl1;
            Name = "Form1";
            Text = "TAMSA";
            Load += Form1_Load;
            materialTabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private MaterialSkin.Controls.MaterialTabControl materialTabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private ImageList imageList1;
        private PictureBox pictureBox1;
        private Label label1;
        private PictureBox pictureBox2;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox7;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox6;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox5;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox4;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox3;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox2;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox1;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox8;
        private MaterialSkin.Controls.MaterialComboBox materialComboBox3;
        private MaterialSkin.Controls.MaterialComboBox materialComboBox2;
        private MaterialSkin.Controls.MaterialComboBox materialComboBox1;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox10;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox9;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox12;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox11;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialComboBox materialComboBox4;
        private MaterialSkin.Controls.MaterialTextBox materialTextBox13;
        private MaterialSkin.Controls.MaterialButton materialButton1;
    }
}

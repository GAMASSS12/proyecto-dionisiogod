using MaterialSkin;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace PROYETO
{
    public partial class Form1 : MaterialSkin.Controls.MaterialForm
    {
        SqlConnection cn = new SqlConnection("Data Source=LAPTOP-C99EQE0Q\\SQLEXPRESS;Initial Catalog=TAMSA;Integrated Security=True;Encrypt=False");
        public Form1()
        {
            InitializeComponent();
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.DeepOrange700, TextShade.WHITE);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void materialComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void materialButton1_Click(object sender, EventArgs e)
        {
            Form formulario = new Form2();
            formulario.Show();
            



                string nuevaSituacion = materialButton1_Click.Text.Trim();

                if (string.IsNullOrEmpty(nuevaSituacion))
                {
                    MessageBox.Show("Por favor, ingresa una situaci�n v�lida.");
                    return;
                }

                using (SqlConnection cn = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO SituacionesMedicas (nombre) VALUES (@nombre)";

                    using (SqlCommand cmd = new SqlCommand(query, cn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", nuevaSituacion);

                        try
                        {
                            cn.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Situaci�n registrada exitosamente.");
                            CargarComboBox(ComboBoxSituacion, "SituacionesMedicas"); // Recarga el ComboBox de situaciones
                            TextBoxNuevaSituacion.Clear(); // Limpia el TextBox despu�s de registrar
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message);
                        }
                    }
                }
            

        }


        private void materialTextBox5_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void materialTextBox7_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void materialTextBox11_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void materialTextBox12_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void materialTextBox13_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void materialTextBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void materialTextBox2_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void materialTextBox8_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void materialTextBox9_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void materialTextBox10_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
